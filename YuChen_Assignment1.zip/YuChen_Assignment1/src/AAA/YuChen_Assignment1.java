package AAA;


import java.util.Scanner;
import java.io.*;
public class oscar {   

    
        public static void main(String[] args) throws IOException {
        

                BufferedReader CoT = new BufferedReader(new InputStreamReader(System.in));
               
                System.out.println("Would you like to have a cup of tea or coffee? Please enter coffee or tea");
                String Q1 = CoT.readLine();

                    if(Q1.equalsIgnoreCase("coffee"))
                        {
                        BufferedReader BBBB = new BufferedReader(new InputStreamReader(System.in));
                        System.out.println("Which kind of coffee do you like? You can choose Espresso, Americano, Latte Macchiato" );
                        String which_coffee =BBBB.readLine();
                        if (which_coffee.equalsIgnoreCase("Espresso")){
                            BufferedReader EPsugar = new BufferedReader(new InputStreamReader(System.in));
                            System.out.println("How much sugar do you like ? please 1~3");
                            String Q4 =EPsugar .readLine();
                            BufferedReader EPmilk = new BufferedReader(new InputStreamReader(System.in));
                            System.out.println("How much milk do you like ? please 1~3");
                            String Q5 =EPmilk .readLine();

                            System.out.println("Here is your Espressp "+Q4+ " sugar "+Q5+" milk!");
                        }
                    
                        else if (which_coffee.equalsIgnoreCase("Americano"))
                        {
                            BufferedReader AMsugar = new BufferedReader(new InputStreamReader(System.in));
                            System.out.println("How much sugar do you like ? please 1~3");
                            String Q6 =AMsugar .readLine();
                            BufferedReader AMmilk = new BufferedReader(new InputStreamReader(System.in));
                            System.out.println("How much milk do you like ? please 1~3");
                            String Q7 =AMmilk .readLine();
                            System.out.println("Here is your Americano "+Q6+ " sugar "+Q7+" milk!");
                        } 
                        else if (which_coffee.equalsIgnoreCase("Latte Macchiato"))
                        {
                            BufferedReader LMsugar = new BufferedReader(new InputStreamReader(System.in));
                            System.out.println("How much sugar do you like ? please 1~3");
                            String Q8 =LMsugar .readLine();
                            BufferedReader LMmilk = new BufferedReader(new InputStreamReader(System.in));
                            System.out.println("How much milk do you like ? please 1~3");
                            String Q9 =LMmilk .readLine();
                            System.out.println("Here is your Americano "+Q8+ " sugar "+Q9+" milk!");
                        }
                        else 
                                {
                                    System.out.println("Please restar again"); 
                                }
                            }

                        else if(Q1.equalsIgnoreCase("tea")){
                      
                            BufferedReader teaQ = new BufferedReader(new InputStreamReader(System.in));
                            System.out.println("Which kind of tea do you like? You can choose Black Tea, Green Tee and Yellow Tea");
                            String which_tea =teaQ.readLine();
                            
                            if (which_tea.equalsIgnoreCase("black tea")){
                                System.out.println("Here is your black tea!");
                            }
                                else if (which_tea.equalsIgnoreCase("green tea")){
                                    System.out.println("Here is your green tea!");
                                }
                                else if (which_tea.equalsIgnoreCase("yellow tea")){
                                    System.out.println("Here is your Yellow tea!");
                                }
                                else 
                                {
                                    System.out.println("Please restar again"); 
                                }
                        
                            }

                        else {
                            System.out.println("Please restar again");
                        }
                        
                    }
                }         

       
           
         



    
   